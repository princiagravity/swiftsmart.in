
    <div class="intro-wrapper d-flex align-items-center justify-content-center text-center">
      <!-- Background Shape-->
      <div class="background-shape"></div>
      <div class="container"><img class="big-logo" src="<?php echo base_url()?>img/core-img/logo-white.png" alt=""></div>
    </div>
    <div class="get-started-btn"><a class="btn btn-success btn-lg w-100" href="<?php echo site_url('DeliveryController/login')?>">Get Started</a></div>
  