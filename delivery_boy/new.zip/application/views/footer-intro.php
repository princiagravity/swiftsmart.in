  <!-- All JavaScript Files-->
  <script src="<?php echo base_url()?>js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url()?>js/jquery.min.js"></script>
    <script src="<?php echo base_url()?>js/waypoints.min.js"></script>
    <script src="<?php echo base_url()?>js/jquery.easing.min.js"></script>
    <script src="<?php echo base_url()?>js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url()?>js/jquery.counterup.min.js"></script>
    <script src="<?php echo base_url()?>js/jquery.countdown.min.js"></script>
    <script src="<?php echo base_url()?>js/default/jquery.passwordstrength.js"></script>
    <script src="<?php echo base_url()?>js/default/dark-mode-switch.js"></script>
    <script src="<?php echo base_url()?>js/default/active.js"></script>
    <script src="<?php echo base_url()?>js/pwa.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="<?php echo base_url()?>js/deliveryboy-functions.js"></script>
    <script type = 'text/javascript'> var base_url= window.location.origin+'/index.php/'; </script>
  </body>
</html>