 <!-- Internet Connection Status-->
 <div class="internet-connection-status" id="internetStatus"></div>
    <!-- Footer Nav-->
    <div class="footer-nav-area" id="footerNav">
      <div class="container h-100 px-0">
        <div class="suha-footer-nav h-100">
          <ul class="h-100 d-flex align-items-center justify-content-between ps-0">
            <!--<li class="active"><a href="home.html"><i class="lni lni-home"></i>Home</a></li>-->
            <!--<li><a href="message.html"><i class="lni lni-life-ring"></i>Support</a></li>-->
            <!--<li><a href="cart.html"><i class="lni lni-shopping-basket"></i>Cart</a></li>-->
            <!--<li><a href="pages.html"><i class="lni lni-heart"></i>Pages</a></li>-->
            <!--<li><a href="settings.html"><i class="lni lni-cog"></i>Settings</a></li>-->
          </ul>
        </div>
      </div>
    </div>
    <!-- All JavaScript Files-->
    <script src="<?php echo base_url()?>js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url()?>js/jquery.min.js"></script>
    <script src="<?php echo base_url()?>js/waypoints.min.js"></script>
    <script src="<?php echo base_url()?>js/jquery.easing.min.js"></script>
    <script src="<?php echo base_url()?>js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url()?>js/jquery.counterup.min.js"></script>
    <script src="<?php echo base_url()?>js/jquery.countdown.min.js"></script>
    <script src="<?php echo base_url()?>js/default/jquery.passwordstrength.js"></script>
    <script src="<?php echo base_url()?>js/default/dark-mode-switch.js"></script>
    <script src="<?php echo base_url()?>js/default/no-internet.js"></script>
    <script src="<?php echo base_url()?>js/default/active.js"></script>
    <script src="<?php echo base_url()?>js/pwa.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="<?php echo base_url()?>js/deliveryboy-functions.js"></script>
    <script type = 'text/javascript'> var base_url= window.location.origin+'/index.php/'; </script>
  </body>
</html>