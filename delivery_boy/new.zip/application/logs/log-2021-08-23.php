<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-23 17:43:14 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-23 17:43:17 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-23 17:43:26 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-23 17:44:47 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-23 17:44:51 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-23 17:44:53 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-23 17:50:04 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-23 17:50:05 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-23 17:50:12 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-23 17:50:37 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-23 20:20:30 --> 404 Page Not Found: DeliveryController/img
