<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-01 08:08:07 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-01 08:08:08 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 08:08:17 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 08:08:33 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 13:30:16 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-01 13:30:16 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 13:30:23 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 13:32:13 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 13:36:50 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 13:37:07 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 13:40:31 --> 404 Page Not Found: DeliveryController/intro.html
ERROR - 2021-08-01 13:40:34 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 13:40:38 --> 404 Page Not Found: DeliveryController/intro.html
ERROR - 2021-08-01 13:41:00 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-01 13:41:00 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 13:41:07 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 13:41:22 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 14:39:38 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-01 18:26:53 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-01 18:26:54 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 18:27:03 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 19:35:22 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-01 19:35:32 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 19:36:10 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 19:47:19 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 19:48:33 --> Severity: Notice --> Undefined property: stdClass::$phone_no /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/home.php 23
ERROR - 2021-08-01 19:48:34 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 19:50:07 --> Severity: Notice --> Undefined property: stdClass::$phone_no /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/home.php 23
ERROR - 2021-08-01 19:50:08 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 19:51:06 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-01 19:52:02 --> 404 Page Not Found: DeliveryController/service-worker.js
