<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-13 07:29:35 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-13 07:29:36 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-13 12:47:50 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-13 12:47:50 --> 404 Page Not Found: DeliveryController/service-worker.js
