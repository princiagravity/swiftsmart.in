<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-19 10:13:05 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-19 10:13:06 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-19 10:13:14 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-19 10:13:45 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-19 10:14:07 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-19 10:14:14 --> 404 Page Not Found: DeliveryController/profile.html
ERROR - 2021-08-19 10:14:21 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-19 10:14:29 --> 404 Page Not Found: DeliveryController/notification-details.html
ERROR - 2021-08-19 10:14:32 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-19 10:15:30 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-19 10:15:32 --> 404 Page Not Found: DeliveryController/service-worker.js
