<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-09 05:49:39 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-09 05:49:39 --> 404 Page Not Found: DeliveryController/service-worker.js
