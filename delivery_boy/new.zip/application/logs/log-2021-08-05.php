<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-05 04:45:29 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-05 04:45:30 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-05 04:45:43 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-05 04:46:11 --> 404 Page Not Found: DeliveryController/profile.html
ERROR - 2021-08-05 04:46:13 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-05 04:52:38 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-05 04:52:46 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-05 13:35:23 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-05 13:35:23 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-05 13:35:30 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-05 13:35:31 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-05 13:35:51 --> 404 Page Not Found: DeliveryController/home.html
ERROR - 2021-08-05 13:35:54 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-05 13:35:56 --> 404 Page Not Found: DeliveryController/home.html
ERROR - 2021-08-05 13:35:58 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-05 16:51:21 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-05 16:51:21 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-05 16:51:29 --> 404 Page Not Found: DeliveryController/service-worker.js
