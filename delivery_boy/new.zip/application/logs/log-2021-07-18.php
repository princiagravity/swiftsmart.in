<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-18 19:00:20 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-07-18 19:00:22 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-18 19:05:43 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-07-18 19:05:43 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-18 19:06:51 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-07-18 19:06:52 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-18 19:07:06 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-18 19:08:00 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-18 19:08:44 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-18 19:09:00 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-18 19:10:15 --> 404 Page Not Found: DeliveryController/profile.html
ERROR - 2021-07-18 19:10:17 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-18 19:10:38 --> 404 Page Not Found: DeliveryController/settings.html
ERROR - 2021-07-18 19:10:41 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-18 19:12:00 --> 404 Page Not Found: DeliveryController/service-worker.js
