<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-27 18:08:53 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-27 18:08:56 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-27 18:09:09 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-27 18:09:17 --> 404 Page Not Found: DeliveryController/profile.html
ERROR - 2021-08-27 19:50:12 --> 404 Page Not Found: DeliveryController/img
