<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-07 06:28:15 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-07 06:28:17 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-07 06:28:25 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-07 06:28:29 --> 404 Page Not Found: DeliveryController/profile.html
ERROR - 2021-09-07 06:28:40 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-07 06:39:03 --> 404 Page Not Found: DeliveryController/img
