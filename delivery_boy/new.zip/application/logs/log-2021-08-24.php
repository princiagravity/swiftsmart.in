<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-24 10:41:26 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-24 10:41:27 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-24 10:41:33 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-24 10:41:40 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-24 10:41:45 --> 404 Page Not Found: DeliveryController/cart.html
ERROR - 2021-08-24 23:09:08 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-24 23:09:09 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-24 23:09:11 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-24 23:09:15 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-24 23:12:02 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-24 23:12:07 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-24 23:12:11 --> 404 Page Not Found: DeliveryController/service-worker.js
