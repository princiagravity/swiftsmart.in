<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-15 08:47:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Delivery_model /home2/gravigw4/public_html/gravity_project/delivery_boy/system/core/Loader.php 348
ERROR - 2021-07-15 09:01:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Delivery_model /home2/gravigw4/public_html/gravity_project/delivery_boy/system/core/Loader.php 348
ERROR - 2021-07-15 09:07:31 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-07-15 09:07:31 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-15 09:07:51 --> Query error: Table 'gravigw4_pwa_test.user_details' doesn't exist - Invalid query: select id,username,mobile,name,role from user_details where mobile='3333333333' and password='3333333333'
ERROR - 2021-07-15 09:07:59 --> Query error: Table 'gravigw4_pwa_test.user_details' doesn't exist - Invalid query: select id,username,mobile,name,role from user_details where mobile='3333333333' and password='3333333333'
ERROR - 2021-07-15 09:08:32 --> Query error: Table 'gravigw4_pwa_test.user_details' doesn't exist - Invalid query: select id,username,mobile,name,role from user_details where mobile='3333333333' and password='3333333333'
ERROR - 2021-07-15 09:27:49 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-07-15 09:27:50 --> 404 Page Not Found: DeliveryController/service-worker.js
