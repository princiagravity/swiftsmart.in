<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-16 11:41:18 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-07-16 11:41:19 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-16 11:41:58 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-16 11:42:22 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-16 11:44:09 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-16 11:44:11 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-16 11:44:13 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-16 11:44:15 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-16 11:44:16 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-16 11:44:38 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-16 22:32:29 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-07-16 22:32:30 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-16 22:32:47 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-16 22:35:58 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-16 22:36:23 --> 404 Page Not Found: DeliveryController/service-worker.js
