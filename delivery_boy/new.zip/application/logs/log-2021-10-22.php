<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-22 16:00:25 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-22 16:00:32 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-22 16:00:45 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-22 16:07:06 --> 404 Page Not Found: DeliveryController/service-worker.js
