<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-04 19:42:58 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-04 19:42:58 --> 404 Page Not Found: DeliveryController/service-worker.js
