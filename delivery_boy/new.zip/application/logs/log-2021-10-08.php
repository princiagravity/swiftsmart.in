<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-08 15:56:31 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-08 15:56:39 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-08 15:57:20 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-08 15:57:22 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-08 15:57:31 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-08 15:57:51 --> 404 Page Not Found: Service-workerjs/index
