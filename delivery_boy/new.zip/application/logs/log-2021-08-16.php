<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-16 08:26:00 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-16 08:26:01 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-16 08:26:07 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-16 08:26:15 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-16 08:26:20 --> 404 Page Not Found: DeliveryController/profile.html
ERROR - 2021-08-16 08:26:23 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-16 08:47:15 --> 404 Page Not Found: DeliveryController/img
