<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-24 06:15:39 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-07-24 06:15:40 --> 404 Page Not Found: DeliveryController/service-worker.js
