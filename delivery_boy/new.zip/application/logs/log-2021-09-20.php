<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-20 03:56:36 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-20 03:56:47 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-20 03:56:54 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-20 03:57:03 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-20 05:51:47 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-20 05:52:02 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-20 05:52:08 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-20 05:52:20 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-20 06:21:39 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-20 06:21:51 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-20 06:21:54 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-20 06:21:58 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-20 06:28:11 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-20 06:29:23 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-20 06:29:25 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-20 06:31:52 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-20 06:31:57 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-20 10:27:53 --> 404 Page Not Found: DeliveryController/service-worker.js
