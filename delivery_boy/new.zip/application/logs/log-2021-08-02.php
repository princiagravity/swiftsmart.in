<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-02 06:58:59 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-02 06:59:01 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-02 06:59:39 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-02 07:00:05 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-02 07:43:06 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-02 07:43:06 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-02 07:43:19 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-02 07:44:50 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-02 07:45:50 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-02 07:46:10 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-02 11:59:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select id,customer_id,order_time,order_total,loc_latitude,loc_longitude,payment_type,status from order_details where delivery_boy_id=
ERROR - 2021-08-02 11:59:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select id,customer_id,order_time,order_total,loc_latitude,loc_longitude,payment_type,status from order_details where delivery_boy_id=
ERROR - 2021-08-02 11:59:49 --> 404 Page Not Found: DeliveryController/service-worker.js
