<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-26 04:52:07 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-26 04:52:13 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-26 04:52:17 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-10-26 05:04:20 --> 404 Page Not Found: DeliveryController/service-worker.js
