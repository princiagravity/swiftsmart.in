<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-25 05:06:30 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 05:06:37 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 05:06:41 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 05:06:47 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-25 05:06:55 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 05:06:57 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 10:16:33 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 10:16:42 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 10:16:45 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 10:17:59 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 10:18:08 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 10:21:21 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 10:21:31 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 10:21:36 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-25 10:22:00 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 10:22:03 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-25 10:22:13 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
