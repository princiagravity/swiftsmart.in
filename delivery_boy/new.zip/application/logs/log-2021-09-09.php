<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-09 04:15:11 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-09 04:15:12 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 04:15:51 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 04:16:21 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 04:16:24 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 04:16:48 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 04:16:50 --> 404 Page Not Found: DeliveryController/home.html
ERROR - 2021-09-09 04:16:53 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 04:17:23 --> 404 Page Not Found: Service-workerjs/index
ERROR - 2021-09-09 04:17:25 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-09 04:17:25 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 04:17:31 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 04:17:56 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 04:18:45 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-09 04:18:45 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 04:18:53 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 04:26:47 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 08:32:53 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-09 08:32:54 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 08:32:58 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 08:33:03 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 08:33:11 --> 404 Page Not Found: Service-workerjs/index
ERROR - 2021-09-09 08:33:12 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-09 08:33:12 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 08:33:21 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 08:33:24 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 08:33:33 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 08:34:37 --> 404 Page Not Found: Service-workerjs/index
ERROR - 2021-09-09 08:34:38 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-09 08:34:38 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 08:35:48 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 08:35:52 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 08:35:54 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-09 08:35:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-09 08:35:55 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-09 08:35:55 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-09 08:36:31 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 08:36:35 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-09 08:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-09 08:36:35 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-09 08:36:35 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-09 08:36:39 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 16:11:26 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-09 16:11:27 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 16:11:34 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 16:11:38 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 16:11:44 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-09 16:11:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-09 16:11:44 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-09 16:11:44 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-09 16:12:52 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-09 16:12:54 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-09 16:12:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-09 16:12:54 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-09 16:12:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-09 16:12:54 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-09 16:12:55 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-09 16:13:13 --> 404 Page Not Found: Service-workerjs/index
