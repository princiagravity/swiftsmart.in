<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-18 15:32:43 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-18 15:32:55 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-18 15:33:00 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-18 15:33:10 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-18 15:33:29 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-18 15:33:35 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-18 15:33:47 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-18 15:33:50 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-18 15:33:54 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-18 15:34:16 --> 404 Page Not Found: Service-workerjs/index
