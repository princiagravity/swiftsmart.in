<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-14 12:55:36 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-14 12:55:39 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-14 12:55:41 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-10-14 15:15:53 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
