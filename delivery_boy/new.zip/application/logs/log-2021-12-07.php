<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-07 05:47:40 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-12-07 06:13:43 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-12-07 06:13:50 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-12-07 06:14:01 --> 404 Page Not Found: Service-workerjs/index
