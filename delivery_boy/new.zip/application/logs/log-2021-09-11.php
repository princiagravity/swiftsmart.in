<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-11 02:44:03 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-11 02:44:12 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-11 02:46:14 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-11 02:46:28 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-11 10:32:32 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-11 10:32:45 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-11 10:32:54 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-11 10:32:57 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-11 10:33:00 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-11 10:34:31 --> 404 Page Not Found: DeliveryController/service-worker.js
