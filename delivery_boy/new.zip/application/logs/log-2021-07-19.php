<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-19 06:57:24 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-07-19 06:57:25 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-19 06:57:34 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-19 06:57:58 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-19 06:58:07 --> 404 Page Not Found: DeliveryController/register.html
ERROR - 2021-07-19 06:58:10 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-19 06:58:24 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-07-19 07:02:26 --> 404 Page Not Found: DeliveryController/img
