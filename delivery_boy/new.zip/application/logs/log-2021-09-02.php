<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-02 06:54:03 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-02 06:54:03 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:54:09 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:54:13 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:54:26 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:54:26 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:54:27 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:54:59 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:55:01 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 45
ERROR - 2021-09-02 06:55:01 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 120
ERROR - 2021-09-02 06:55:01 --> Severity: Notice --> Trying to get property 'addresstype' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 121
ERROR - 2021-09-02 06:55:01 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 122
ERROR - 2021-09-02 06:55:01 --> Severity: Notice --> Trying to get property 'area_name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 123
ERROR - 2021-09-02 06:55:01 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 124
ERROR - 2021-09-02 06:55:01 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:55:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:55:01 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 202
ERROR - 2021-09-02 06:55:01 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 203
ERROR - 2021-09-02 06:55:01 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 204
ERROR - 2021-09-02 06:55:02 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:55:02 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:55:07 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:55:09 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:55:10 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:55:10 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:55:39 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:55:44 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:55:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:55:45 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:55:46 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:55:55 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:55:57 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:55:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:55:57 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:55:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:55:58 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:55:58 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:56:02 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:56:06 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:07 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:56:08 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:56:11 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-02 06:56:13 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 45
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 120
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'addresstype' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 121
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 122
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'area_name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 123
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 124
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 202
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 203
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 204
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 45
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 120
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'addresstype' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 121
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 122
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'area_name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 123
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 124
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 202
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 203
ERROR - 2021-09-02 06:56:14 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 204
ERROR - 2021-09-02 06:56:14 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:56:15 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:56:17 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:56:18 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:19 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:56:19 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:56:21 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:56:22 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 45
ERROR - 2021-09-02 06:56:22 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 120
ERROR - 2021-09-02 06:56:22 --> Severity: Notice --> Trying to get property 'addresstype' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 121
ERROR - 2021-09-02 06:56:22 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 122
ERROR - 2021-09-02 06:56:22 --> Severity: Notice --> Trying to get property 'area_name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 123
ERROR - 2021-09-02 06:56:22 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 124
ERROR - 2021-09-02 06:56:22 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:22 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 202
ERROR - 2021-09-02 06:56:22 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 203
ERROR - 2021-09-02 06:56:22 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 204
ERROR - 2021-09-02 06:56:22 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:56:22 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:56:24 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:56:25 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:26 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:56:26 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:56:31 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:56:32 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:32 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:56:33 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:56:49 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:56:51 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:51 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:56:51 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:56:55 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:56:56 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-02 06:56:56 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-02 06:56:57 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-02 06:57:12 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:57:13 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-02 06:57:14 --> 404 Page Not Found: DeliveryController/service-worker.js
