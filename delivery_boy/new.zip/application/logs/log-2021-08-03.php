<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-03 06:00:39 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-03 06:00:39 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-03 18:04:25 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-03 18:04:26 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-03 18:04:35 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-03 18:04:44 --> 404 Page Not Found: DeliveryController/profile.html
