<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-10 16:02:39 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-10 16:02:39 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:02:57 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:03:26 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:04:32 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-10 16:04:34 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:05:31 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-10 16:05:32 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:05:37 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-10 16:05:38 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:08:19 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:08:22 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:08:30 --> 404 Page Not Found: DeliveryController/settings.html
ERROR - 2021-09-10 16:08:34 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:08:35 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:08:46 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:09:02 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:09:07 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:09:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:09:07 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 16:09:08 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-10 16:11:59 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:11:59 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 16:12:00 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-10 16:12:08 --> Query error: Unknown column 'profile.html' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=profile.html
ERROR - 2021-09-10 16:12:21 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:12:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:12:22 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 16:12:22 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-10 16:13:25 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:13:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:13:25 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 16:13:26 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-10 16:16:17 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:16:17 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 16:16:17 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-10 16:16:19 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:16:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:16:19 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 16:16:19 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-10 16:16:20 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:16:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:16:21 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 16:16:21 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-10 16:16:32 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:16:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:16:33 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 16:16:33 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-10 16:16:35 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:16:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:16:35 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 16:16:36 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-10 16:16:38 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:16:40 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 16:16:41 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:16:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:16:41 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 16:16:41 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-10 16:48:42 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:48:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 16:48:43 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 16:48:44 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 17:13:01 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 17:13:35 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 17:13:50 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 17:13:57 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-10 17:13:59 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 17:13:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 17:13:59 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 17:14:00 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-10 17:14:15 --> 404 Page Not Found: Service-workerjs/index
ERROR - 2021-09-10 17:14:18 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 17:14:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-10 17:14:18 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-10 17:14:18 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
