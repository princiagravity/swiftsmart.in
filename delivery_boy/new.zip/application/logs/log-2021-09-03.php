<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-03 17:21:17 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-09-03 17:21:17 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-03 17:21:24 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-03 17:21:28 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-03 17:21:31 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-03 17:21:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-03 17:21:31 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-03 17:21:31 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-03 17:22:15 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-03 17:22:16 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-03 17:22:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-03 17:22:17 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-03 17:22:17 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-03 17:22:18 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-03 17:22:19 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-03 17:22:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-03 17:22:20 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-03 17:22:20 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-03 17:22:37 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-03 17:22:40 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 45
ERROR - 2021-09-03 17:22:40 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 120
ERROR - 2021-09-03 17:22:40 --> Severity: Notice --> Trying to get property 'addresstype' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 121
ERROR - 2021-09-03 17:22:40 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 122
ERROR - 2021-09-03 17:22:40 --> Severity: Notice --> Trying to get property 'area_name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 123
ERROR - 2021-09-03 17:22:40 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 124
ERROR - 2021-09-03 17:22:40 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-03 17:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-09-03 17:22:40 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 202
ERROR - 2021-09-03 17:22:40 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 203
ERROR - 2021-09-03 17:22:40 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 204
ERROR - 2021-09-03 17:22:41 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-09-03 17:22:41 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-03 17:22:44 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-03 17:22:44 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-03 17:22:55 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-03 17:22:58 --> 404 Page Not Found: DeliveryController/profile.html
