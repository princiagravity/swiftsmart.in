<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-28 10:03:06 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-28 10:03:15 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-28 10:03:20 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-28 10:03:27 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-28 10:04:19 --> 404 Page Not Found: DeliveryController/service-worker.js
