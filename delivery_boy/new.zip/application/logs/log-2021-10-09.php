<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-09 05:17:52 --> 404 Page Not Found: Service-workerjs/index
ERROR - 2021-10-09 05:28:42 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-09 05:28:52 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-09 05:28:56 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-09 05:28:58 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-10-09 05:29:06 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-09 05:29:08 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-09 05:29:40 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-10-09 05:29:49 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-09 05:30:59 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-09 05:31:07 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-09 05:31:20 --> 404 Page Not Found: DeliveryController/service-worker.js
