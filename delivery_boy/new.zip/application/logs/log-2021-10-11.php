<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-11 10:07:21 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-11 10:07:33 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-11 10:07:43 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-11 10:07:57 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-11 10:08:04 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-11 15:33:18 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-11 16:08:27 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-11 16:08:41 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-11 16:11:42 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-10-11 16:13:22 --> 404 Page Not Found: DeliveryController/service-worker.js
