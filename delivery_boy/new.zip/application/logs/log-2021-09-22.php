<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-22 05:04:33 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-22 05:04:47 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-22 05:04:51 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-22 05:05:11 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-22 05:06:09 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-22 05:06:12 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-22 05:06:15 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-22 05:06:19 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-22 05:06:23 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-22 05:06:32 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 23
ERROR - 2021-09-22 05:06:32 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 24
ERROR - 2021-09-22 05:06:32 --> Severity: Notice --> Trying to get property 'addresstype' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 25
ERROR - 2021-09-22 05:06:32 --> Severity: Notice --> Trying to get property 'area_name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 26
ERROR - 2021-09-22 05:06:32 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 27
ERROR - 2021-09-22 05:06:32 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 27
ERROR - 2021-09-22 05:06:33 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-22 05:06:36 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-22 05:06:53 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-09-22 05:07:12 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,total_before_vat,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-09-22 05:07:14 --> 404 Page Not Found: DeliveryController/service-worker.js
