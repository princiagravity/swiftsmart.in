<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-25 07:27:33 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-25 07:27:34 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 07:27:42 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 07:27:46 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 10:42:35 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-25 10:42:36 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 10:42:40 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 10:42:46 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 10:42:56 --> 404 Page Not Found: Service-workerjs/index
ERROR - 2021-08-25 10:42:58 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-25 10:42:59 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 10:43:15 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 10:43:21 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 11:17:23 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 11:17:32 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 11:21:51 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 11:22:01 --> 404 Page Not Found: Service-workerjs/index
ERROR - 2021-08-25 11:22:03 --> 404 Page Not Found: DeliveryController/img
ERROR - 2021-08-25 11:22:03 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 11:22:15 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 11:22:20 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 11:22:23 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-08-25 11:22:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-08-25 11:22:24 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-08-25 11:22:24 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-08-25 11:22:44 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 11:32:18 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 11:32:22 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-08-25 11:32:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-08-25 11:32:22 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-08-25 11:32:23 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-08-25 11:32:25 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 11:32:26 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-08-25 11:32:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-08-25 11:32:26 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-08-25 11:32:26 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-08-25 11:32:30 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 11:32:32 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-08-25 11:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-08-25 11:32:33 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-08-25 11:32:33 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
ERROR - 2021-08-25 11:32:35 --> 404 Page Not Found: DeliveryController/service-worker.js
ERROR - 2021-08-25 11:32:37 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 45
ERROR - 2021-08-25 11:32:37 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 120
ERROR - 2021-08-25 11:32:37 --> Severity: Notice --> Trying to get property 'addresstype' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 121
ERROR - 2021-08-25 11:32:37 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 122
ERROR - 2021-08-25 11:32:37 --> Severity: Notice --> Trying to get property 'area_name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 123
ERROR - 2021-08-25 11:32:37 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 124
ERROR - 2021-08-25 11:32:37 --> Severity: Notice --> Undefined variable: deliveryboy_details /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-08-25 11:32:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 176
ERROR - 2021-08-25 11:32:37 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 202
ERROR - 2021-08-25 11:32:37 --> Severity: Notice --> Trying to get property 'mobile' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 203
ERROR - 2021-08-25 11:32:37 --> Severity: Notice --> Trying to get property 'address' of non-object /home2/gravigw4/public_html/gravity_project/delivery_boy/application/views/order_details.php 204
ERROR - 2021-08-25 11:32:37 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-08-25 11:32:38 --> Query error: Unknown column 'service' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=service-worker.js
