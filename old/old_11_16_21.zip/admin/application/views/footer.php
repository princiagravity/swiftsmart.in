</div>
      <!-- Wrapper END -->
      <!-- Footer -->
      <footer class="bg-white iq-footer">
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-6">
                  <ul class="list-inline mb-0">
                   
                  </ul>
               </div>
               <div class="col-lg-6 text-right">
                  Copyright 2021 <a href="#">Gravity Innovative Solutions </a> All Rights Reserved.
               </div>
            </div>
         </div>
      </footer>
      <!-- Footer END -->
      <!-- Optional JavaScript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="<?php echo base_url()?>js/jquery.min.js"></script>
      <script src="<?php echo base_url()?>js/popper.min.js"></script>
      <script src="<?php echo base_url()?>js/bootstrap.min.js"></script>
      <!-- Appear JavaScript -->
      <script src="<?php echo base_url()?>js/jquery.appear.js"></script>
      <!-- Countdown JavaScript -->
      <script src="<?php echo base_url()?>js/countdown.min.js"></script>
      <!-- Counterup JavaScript -->
      <script src="<?php echo base_url()?>js/waypoints.min.js"></script>
      <script src="<?php echo base_url()?>js/jquery.counterup.min.js"></script>
      <!-- Wow JavaScript -->
      <script src="<?php echo base_url()?>js/wow.min.js"></script>
      <!-- Apexcharts JavaScript -->
      <script src="<?php echo base_url()?>js/apexcharts.js"></script>
      <!-- Slick JavaScript -->
      <script src="<?php echo base_url()?>js/slick.min.js"></script>
      <!-- Select2 JavaScript -->
      <script src="<?php echo base_url()?>js/select2.min.js"></script>
      <!-- Owl Carousel JavaScript -->
      <script src="<?php echo base_url()?>js/owl.carousel.min.js"></script>
      <!-- Magnific Popup JavaScript -->
      <script src="<?php echo base_url()?>js/jquery.magnific-popup.min.js"></script>
      <!-- Smooth Scrollbar JavaScript -->
      <script src="<?php echo base_url()?>js/smooth-scrollbar.js"></script>
      <!-- lottie JavaScript -->
      <script src="<?php echo base_url()?>js/lottie.js"></script>
      <!-- core JavaScript -->
      <script src="<?php echo base_url()?>js/core.js"></script>
      <!-- charts JavaScript -->
      <script src="<?php echo base_url()?>js/charts.js"></script>
      <!-- animated JavaScript -->
      <script src="<?php echo base_url()?>js/animated.js"></script>
      <!-- Chart Custom JavaScript -->
      <script src="<?php echo base_url()?>js/chart-custom.js"></script>
      <!-- Custom JavaScript -->
      <script src="<?php echo base_url()?>js/custom.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js" integrity="sha512-T/tUfKSV1bihCnd+MxKD0Hm1uBBroVYBOYSk1knyvQ9VyZJpc/ALb4P0r6ubwVPSGB2GvjeoMAJJImBG12TiaQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script src="<?php echo base_url()?>js/select2.min.js"></script>
      <!-- By Princia-->
      <script src="<?php echo base_url()?>js/custom_functions.js"></script>
      <script type = 'text/javascript'> var base_url= window.location.origin+'/admin/index.php/';</script>
  
   </body>
</html>
