<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-31 09:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 09:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 09:51:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 09:51:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 09:51:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 09:51:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 09:51:19 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-31 09:58:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 09:58:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 09:59:08 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-31 10:12:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 10:12:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 10:13:02 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-31 10:14:34 --> 404 Page Not Found: Img/core-img
ERROR - 2021-08-31 15:39:09 --> Severity: Notice --> Undefined variable: category /home2/gravigw4/public_html/gravity_project/admin/application/views/delivery-charges.php 46
ERROR - 2021-08-31 15:39:23 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-31 15:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 15:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 15:43:44 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-31 15:43:53 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-31 15:46:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 15:46:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 15:46:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 15:46:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 15:46:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 15:46:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/gravity_project/admin/application/views/promocodes.php 127
ERROR - 2021-08-31 16:24:03 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
