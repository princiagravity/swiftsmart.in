<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home2/gravigw4/public_html/swiftsmart/admin/application/views/promocodes.php 127
ERROR - 2021-09-21 05:41:14 --> Severity: Notice --> Undefined variable: category /home2/gravigw4/public_html/swiftsmart/admin/application/views/delivery-charges.php 46
ERROR - 2021-09-21 05:42:48 --> 404 Page Not Found: Img/core-img
ERROR - 2021-09-21 05:48:01 --> 404 Page Not Found: Img/core-img
ERROR - 2021-09-21 08:30:57 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 08:32:26 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 08:40:39 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 08:48:54 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 08:50:58 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 08:55:34 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 08:56:18 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 08:56:54 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 08:58:01 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 733
ERROR - 2021-09-21 09:00:35 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:03:09 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:03:37 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 733
ERROR - 2021-09-21 09:09:23 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:11:42 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:13:31 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:16:37 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:17:32 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:18:42 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:23:23 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:24:21 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:25:23 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:27:07 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:40:54 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:41:42 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:47:23 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 09:58:24 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 10:03:14 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 10:04:10 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 10:04:50 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 10:05:41 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 10:06:25 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 10:08:19 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 11:13:28 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 11:15:13 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 11:16:41 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 11:17:50 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 11:18:36 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 11:19:09 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 11:19:35 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 11:19:35 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 11:20:11 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 11:23:59 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 11:24:59 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:01:48 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:02:57 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:04:15 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:04:56 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:05:19 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:06:32 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:07:47 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:09:54 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:11:32 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:12:40 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:16:06 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:18:24 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:21:38 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:40:05 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:41:23 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:42:30 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:43:04 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:43:33 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:45:05 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:49:46 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 12:59:31 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:00:12 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:03:35 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:08:20 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:08:45 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:09:17 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:09:57 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:13:21 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:14:06 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:18:15 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:19:50 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:20:12 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:21:33 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:21:57 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:24:17 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:25:18 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:25:52 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:26:27 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:26:59 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:27:36 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:27:57 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:29:36 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:30:08 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:31:05 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-21 13:33:25 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
