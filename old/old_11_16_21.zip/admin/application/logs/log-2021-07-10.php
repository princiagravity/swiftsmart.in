<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-10 17:35:34 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,area,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-10 17:39:46 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,area,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-10 21:42:48 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,area,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
