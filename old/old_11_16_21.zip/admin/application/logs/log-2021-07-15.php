<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-15 06:30:49 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-15 09:13:03 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-15 09:17:02 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-15 09:28:41 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: SELECT user_id,name from delivery_boy_details where area=1
ERROR - 2021-07-15 10:15:45 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: SELECT user_id,name from delivery_boy_details where area=1
ERROR - 2021-07-15 10:15:54 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: SELECT user_id,name from delivery_boy_details where area=1
ERROR - 2021-07-15 10:18:35 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
