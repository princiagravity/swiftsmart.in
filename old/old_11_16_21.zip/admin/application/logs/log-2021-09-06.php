<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-06 06:02:39 --> Severity: Notice --> Undefined variable: data /home2/gravigw4/public_html/swiftsmart/admin/application/models/Admin_model.php 226
ERROR - 2021-09-06 06:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/swiftsmart/admin/application/views/add-product.php 70
ERROR - 2021-09-06 06:02:45 --> Severity: Notice --> Undefined variable: data /home2/gravigw4/public_html/swiftsmart/admin/application/models/Admin_model.php 226
ERROR - 2021-09-06 06:02:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home2/gravigw4/public_html/swiftsmart/admin/application/views/add-product.php 70
