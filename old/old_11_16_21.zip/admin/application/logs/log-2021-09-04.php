<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-04 07:52:09 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-09-04 11:52:30 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
