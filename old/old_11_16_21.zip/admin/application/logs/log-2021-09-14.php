<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-14 13:58:43 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:00:03 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:01:40 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:02:17 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:03:11 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:03:37 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:04:00 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:05:55 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:08:19 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:08:52 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:17:59 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:18:31 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:19:30 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:19:59 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:20:23 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:25:01 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:25:33 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:25:53 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:26:15 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-14 14:28:19 --> 404 Page Not Found: Img/core-img
