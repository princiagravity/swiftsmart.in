<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-26 09:34:54 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/admin/application/models/Admin_model.php 235
ERROR - 2021-07-26 09:34:54 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/admin/application/models/Admin_model.php 235
