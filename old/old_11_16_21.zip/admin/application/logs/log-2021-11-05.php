<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-05 06:44:32 --> 404 Page Not Found: AdminController/img
ERROR - 2021-11-05 12:53:26 --> 404 Page Not Found: AdminController/img
