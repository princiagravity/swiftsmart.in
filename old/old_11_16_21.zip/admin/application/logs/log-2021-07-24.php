<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-24 06:11:12 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-24 12:43:53 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/admin/application/models/Admin_model.php 235
ERROR - 2021-07-24 12:43:53 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/admin/application/models/Admin_model.php 235
ERROR - 2021-07-24 12:44:06 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/admin/application/models/Admin_model.php 235
ERROR - 2021-07-24 12:44:06 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/admin/application/models/Admin_model.php 235
ERROR - 2021-07-24 13:26:40 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/admin/application/models/Admin_model.php 235
ERROR - 2021-07-24 13:26:40 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/admin/application/models/Admin_model.php 235
ERROR - 2021-07-24 13:27:35 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-24 16:23:55 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-24 16:24:52 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
