<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-25 05:13:09 --> 404 Page Not Found: AdminController/img
