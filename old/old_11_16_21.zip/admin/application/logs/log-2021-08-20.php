<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-20 01:47:53 --> Severity: Notice --> Undefined variable: category /home2/gravigw4/public_html/gravity_project/admin/application/views/delivery-charges.php 46
ERROR - 2021-08-20 11:32:52 --> Query error: Table 'gravigw4_pwa_test.customer_details' doesn't exist - Invalid query: SELECT id,name,phone_no,address,profile_pic,email_id,area from customer_details where status != 'Deleted' order by created_on desc limit 10
ERROR - 2021-08-20 12:22:34 --> Query error: Table 'gravigw4_pwa_test.customer_details' doesn't exist - Invalid query: SELECT id,name,phone_no,address,profile_pic,email_id,area from customer_details where status != 'Deleted' order by created_on desc limit 10
ERROR - 2021-08-20 17:44:10 --> Query error: Table 'gravigw4_pwa_test.customer_details' doesn't exist - Invalid query: SELECT id,name,phone_no,address,profile_pic,email_id,area from customer_details where status != 'Deleted' order by created_on desc limit 10
ERROR - 2021-08-20 17:55:50 --> Query error: Table 'gravigw4_pwa_test.customer_details' doesn't exist - Invalid query: SELECT id,name,phone_no,address,profile_pic,email_id,area from customer_details where status != 'Deleted' order by created_on desc limit 10
