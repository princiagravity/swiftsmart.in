<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-11 07:08:16 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,area,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-11 07:11:22 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,area,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-11 08:44:26 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-11 08:44:35 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-11 08:44:42 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
