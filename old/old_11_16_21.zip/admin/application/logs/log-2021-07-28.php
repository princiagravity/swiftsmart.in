<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-28 04:13:42 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/admin/application/models/Admin_model.php 246
ERROR - 2021-07-28 04:13:42 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/admin/application/models/Admin_model.php 246
ERROR - 2021-07-28 04:27:38 --> Severity: 8192 --> array_key_exists(): Using array_key_exists() on objects is deprecated. Use isset() or property_exists() instead /home2/gravigw4/public_html/gravity_project/admin/application/controllers/AdminController.php 937
ERROR - 2021-07-28 04:27:38 --> Severity: 8192 --> array_key_exists(): Using array_key_exists() on objects is deprecated. Use isset() or property_exists() instead /home2/gravigw4/public_html/gravity_project/admin/application/controllers/AdminController.php 941
ERROR - 2021-07-28 04:28:49 --> 404 Page Not Found: AdminController/delete-item
ERROR - 2021-07-28 05:36:44 --> Severity: 8192 --> array_key_exists(): Using array_key_exists() on objects is deprecated. Use isset() or property_exists() instead /home2/gravigw4/public_html/gravity_project/admin/application/controllers/AdminController.php 937
ERROR - 2021-07-28 05:36:44 --> Severity: 8192 --> array_key_exists(): Using array_key_exists() on objects is deprecated. Use isset() or property_exists() instead /home2/gravigw4/public_html/gravity_project/admin/application/controllers/AdminController.php 941
ERROR - 2021-07-28 05:40:25 --> Severity: 8192 --> array_key_exists(): Using array_key_exists() on objects is deprecated. Use isset() or property_exists() instead /home2/gravigw4/public_html/gravity_project/admin/application/controllers/AdminController.php 938
ERROR - 2021-07-28 05:40:25 --> Severity: 8192 --> array_key_exists(): Using array_key_exists() on objects is deprecated. Use isset() or property_exists() instead /home2/gravigw4/public_html/gravity_project/admin/application/controllers/AdminController.php 942
ERROR - 2021-07-28 05:42:19 --> Severity: 8192 --> array_key_exists(): Using array_key_exists() on objects is deprecated. Use isset() or property_exists() instead /home2/gravigw4/public_html/gravity_project/admin/application/controllers/AdminController.php 942
ERROR - 2021-07-28 05:46:09 --> 404 Page Not Found: AdminController/delete-item
ERROR - 2021-07-28 06:39:24 --> Severity: Notice --> Undefined variable: category /home2/gravigw4/public_html/gravity_project/admin/application/views/delivery-charges.php 46
ERROR - 2021-07-28 06:40:41 --> Query error: Table 'gravigw4_pwa_test.p' doesn't exist - Invalid query: SELECT *
FROM `p`
WHERE `i` IS NULL
ERROR - 2021-07-28 06:43:04 --> Query error: Table 'gravigw4_pwa_test.p' doesn't exist - Invalid query: SELECT *
FROM `p`
WHERE `i` IS NULL
ERROR - 2021-07-28 08:30:05 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-28 08:35:31 --> Severity: Notice --> Undefined variable: category /home2/gravigw4/public_html/gravity_project/admin/application/views/delivery-charges.php 46
ERROR - 2021-07-28 14:30:33 --> Severity: Notice --> Undefined variable: category /home2/gravigw4/public_html/gravity_project/admin/application/views/delivery-charges.php 46
ERROR - 2021-07-28 17:45:29 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-28 17:49:11 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
