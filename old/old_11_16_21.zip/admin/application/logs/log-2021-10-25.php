<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-25 05:39:26 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:40:16 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:46:39 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:47:35 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:50:52 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:51:28 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:53:31 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:54:11 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:54:54 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:55:42 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:56:51 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:57:26 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:57:54 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 05:57:55 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 06:44:13 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 06:44:46 --> Severity: Notice --> Undefined offset: 1 /home/teamgfa5/public_html/swiftsmart.in/admin/application/controllers/AdminController.php 601
ERROR - 2021-10-25 11:29:22 --> 404 Page Not Found: Img/core-img
ERROR - 2021-10-25 12:56:55 --> 404 Page Not Found: Img/core-img
