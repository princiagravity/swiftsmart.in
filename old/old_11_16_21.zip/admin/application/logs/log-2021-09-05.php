<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-05 13:40:51 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-09-05 13:41:30 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\swiftsmart_new\admin\application\views\delivery-charges.php 46
ERROR - 2021-09-05 13:41:46 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\swiftsmart_new\admin\application\views\delivery-charges.php 46
ERROR - 2021-09-05 13:44:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\swiftsmart_new\admin\application\views\promocodes.php 127
ERROR - 2021-09-05 13:44:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\swiftsmart_new\admin\application\views\promocodes.php 127
ERROR - 2021-09-05 13:44:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\swiftsmart_new\admin\application\views\promocodes.php 127
ERROR - 2021-09-05 13:44:28 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\swiftsmart_new\admin\application\views\delivery-charges.php 46
ERROR - 2021-09-05 13:53:28 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\swiftsmart_new\admin\application\views\delivery-charges.php 46
