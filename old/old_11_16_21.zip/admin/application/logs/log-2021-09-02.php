<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-02 11:45:58 --> 404 Page Not Found: AdminController/img
ERROR - 2021-09-02 11:48:18 --> 404 Page Not Found: AdminController/img
ERROR - 2021-09-02 12:00:49 --> 404 Page Not Found: AdminController/img
ERROR - 2021-09-02 13:04:00 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-09-02 13:04:19 --> Severity: Warning --> getimagesize(): SSL operation failed with code 1. OpenSSL Error messages:
error:1416F086:SSL routines:tls_process_server_certificate:certificate verify failed C:\xampp\htdocs\swiftsmart_new\admin\application\third_party\fpdf\fpdf.php 1238
ERROR - 2021-09-02 13:04:19 --> Severity: Warning --> getimagesize(): Failed to enable crypto C:\xampp\htdocs\swiftsmart_new\admin\application\third_party\fpdf\fpdf.php 1238
ERROR - 2021-09-02 13:04:19 --> Severity: Warning --> getimagesize(https://localhost/swiftsmart_new/admin//logo/fathimalogo.jpg): failed to open stream: operation failed C:\xampp\htdocs\swiftsmart_new\admin\application\third_party\fpdf\fpdf.php 1238
ERROR - 2021-09-02 13:04:19 --> Severity: error --> Exception: FPDF error: Missing or incorrect image file: https://localhost/swiftsmart_new/admin//logo/fathimalogo.jpg C:\xampp\htdocs\swiftsmart_new\admin\application\third_party\fpdf\fpdf.php 271
ERROR - 2021-09-02 13:04:24 --> Severity: Warning --> getimagesize(): SSL operation failed with code 1. OpenSSL Error messages:
error:1416F086:SSL routines:tls_process_server_certificate:certificate verify failed C:\xampp\htdocs\swiftsmart_new\admin\application\third_party\fpdf\fpdf.php 1238
ERROR - 2021-09-02 13:04:24 --> Severity: Warning --> getimagesize(): Failed to enable crypto C:\xampp\htdocs\swiftsmart_new\admin\application\third_party\fpdf\fpdf.php 1238
ERROR - 2021-09-02 13:04:24 --> Severity: Warning --> getimagesize(https://localhost/swiftsmart_new/admin//logo/fathimalogo.jpg): failed to open stream: operation failed C:\xampp\htdocs\swiftsmart_new\admin\application\third_party\fpdf\fpdf.php 1238
ERROR - 2021-09-02 13:04:24 --> Severity: error --> Exception: FPDF error: Missing or incorrect image file: https://localhost/swiftsmart_new/admin//logo/fathimalogo.jpg C:\xampp\htdocs\swiftsmart_new\admin\application\third_party\fpdf\fpdf.php 271
