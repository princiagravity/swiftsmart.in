<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-23 12:50:37 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/admin/application/models/Admin_model.php 177
ERROR - 2021-07-23 12:50:37 --> Severity: Notice --> Trying to get property 'name' of non-object /home2/gravigw4/public_html/gravity_project/admin/application/models/Admin_model.php 177
ERROR - 2021-07-23 12:51:21 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-23 12:51:35 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-07-23 12:51:55 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,tax_amount,order_total,payment_type,status from order_details where id=images
