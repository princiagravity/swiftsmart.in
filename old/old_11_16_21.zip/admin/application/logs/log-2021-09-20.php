<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-20 08:24:26 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 08:25:56 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 08:38:04 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 08:40:30 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 08:44:22 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 08:48:18 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 08:48:59 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 08:49:24 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 08:50:12 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 08:51:36 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 08:53:57 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:01:43 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:03:41 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:06:12 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:07:34 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:08:57 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:10:10 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:11:48 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:13:14 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:13:56 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:16:28 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:17:20 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:20:47 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:22:51 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:24:52 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:25:23 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:28:02 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:32:28 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:47:44 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:48:24 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:49:41 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:52:07 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:52:38 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 09:53:37 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 10:52:09 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 10:57:58 --> 404 Page Not Found: AdminController/img
ERROR - 2021-09-20 11:00:26 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 11:46:29 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 11:49:46 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 12:03:46 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-20 12:09:03 --> 404 Page Not Found: Img/core-img
