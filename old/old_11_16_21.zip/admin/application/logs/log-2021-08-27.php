<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-27 04:09:05 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-27 04:09:17 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-27 04:13:42 --> 404 Page Not Found: Img/core-img
ERROR - 2021-08-27 04:14:22 --> 404 Page Not Found: Img/core-img
ERROR - 2021-08-27 04:14:33 --> 404 Page Not Found: Img/core-img
ERROR - 2021-08-27 04:20:15 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status from order_details where id=images
ERROR - 2021-08-27 04:30:11 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-27 04:30:21 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-27 04:39:39 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-27 04:40:24 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-27 04:40:32 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-27 05:18:03 --> 404 Page Not Found: Img/core-img
ERROR - 2021-08-27 05:51:08 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-27 05:51:20 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-27 07:42:38 --> Severity: Notice --> Undefined index: variants /home2/gravigw4/public_html/gravity_project/admin/application/controllers/AdminController.php 607
ERROR - 2021-08-27 07:42:38 --> Severity: Notice --> Trying to access array offset on value of type null /home2/gravigw4/public_html/gravity_project/admin/application/controllers/AdminController.php 607
ERROR - 2021-08-27 07:42:38 --> Severity: Notice --> Undefined index: variants /home2/gravigw4/public_html/gravity_project/admin/application/controllers/AdminController.php 611
ERROR - 2021-08-27 07:42:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home2/gravigw4/public_html/gravity_project/admin/application/controllers/AdminController.php 611
ERROR - 2021-08-27 07:42:38 --> Query error: Column 'variants' cannot be null - Invalid query: INSERT INTO `product_details` (`image_url`, `name`, `category`, `description`, `status`, `variants`, `mrp`, `price`, `max_sale`, `variants_count`) VALUES ('https://gravity-innovations.com/gravity_project/admin/uploads/product-images/PROD_16300501582.png', 'Masala Dosa', '28', 'Masala dosa ICH', 'In Stock', NULL, '12', '10', '10', 0)
ERROR - 2021-08-27 07:42:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/gravigw4/public_html/gravity_project/admin/system/core/Exceptions.php:271) /home2/gravigw4/public_html/gravity_project/admin/system/core/Common.php 564
ERROR - 2021-08-27 07:56:41 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-27 07:57:02 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-27 08:06:46 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-27 08:08:43 --> Severity: Notice --> Undefined variable: category /home2/gravigw4/public_html/gravity_project/admin/application/views/delivery-charges.php 46
ERROR - 2021-08-27 08:22:59 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-27 08:23:05 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-27 08:26:53 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-27 08:27:32 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-27 08:27:43 --> Query error: Unknown column 'images' in 'where clause' - Invalid query: SELECT id,customer_id,delivery_boy_id,area,cart_total,discount,invoice_no,order_time,tax,delivery_charge,delivery_tax,tax_amount,order_total,payment_type,status,loc_latitude,loc_longitude from order_details where id=images
ERROR - 2021-08-27 12:10:02 --> Severity: Notice --> Undefined variable: category /home2/gravigw4/public_html/gravity_project/admin/application/views/delivery-charges.php 46
ERROR - 2021-08-27 12:10:54 --> Severity: Notice --> Undefined variable: category /home2/gravigw4/public_html/gravity_project/admin/application/views/delivery-charges.php 46
ERROR - 2021-08-27 12:11:03 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-27 12:11:06 --> Severity: Notice --> Undefined variable: category /home2/gravigw4/public_html/gravity_project/admin/application/views/delivery-charges.php 46
ERROR - 2021-08-27 12:11:10 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-27 12:11:13 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-27 12:11:16 --> Severity: Notice --> Undefined variable: category /home2/gravigw4/public_html/gravity_project/admin/application/views/delivery-charges.php 46
ERROR - 2021-08-27 12:11:24 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-27 17:35:07 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-27 17:35:33 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-27 17:35:44 --> 404 Page Not Found: AdminController/img
ERROR - 2021-08-27 17:36:20 --> 404 Page Not Found: AdminController/img
