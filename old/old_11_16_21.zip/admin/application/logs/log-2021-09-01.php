<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-01 08:03:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'gravigw4_pwauser'@'localhost' (using password: YES) C:\xampp\htdocs\laundry\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-09-01 08:03:32 --> Unable to connect to the database
