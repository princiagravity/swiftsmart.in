<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-18 12:59:50 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-18 13:02:35 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-18 13:07:20 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-18 13:09:26 --> Severity: Notice --> Undefined offset: 1 /home2/gravigw4/public_html/swiftsmart/admin/application/controllers/AdminController.php 601
ERROR - 2021-09-18 13:18:27 --> 404 Page Not Found: Img/core-img
