<footer class="py-4 bg-footer mt-auto">
                <div class="container-fluid">
                    <div class="d-flex align-items-center justify-content-between small">
                    <div class="text-muted-1">© 2021 <b>swanthanam</b>. by <a href="https://gravityinnovativesolutions.in/">Gravity Innovations</a></div>                        <div class="footer-links">
                            <a href="#">Privacy Policy</a>
                            <a href="#">Terms &amp; Conditions</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
	
		<!-- file upload pulgin -->
	
	
    <!--<script src="<?php echo base_url();?>admin_html/js/jquery-3.4.1.min.js"></script>--->
    <script src="<?php echo base_url();?>admin_html/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url();?>admin_html/vendor/chart/highcharts.js"></script>
    <script src="<?php echo base_url();?>admin_html/vendor/chart/exporting.js"></script>
    <script src="<?php echo base_url();?>admin_html/vendor/chart/export-data.js"></script>
    <script src="<?php echo base_url();?>admin_html/vendor/chart/accessibility.js"></script>
    <script src="<?php echo base_url();?>admin_html/js/scripts.js"></script>
    <script src="<?php echo base_url();?>admin_html/js/chart.js"></script>
</body>

</html>